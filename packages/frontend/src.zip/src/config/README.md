# Theme Configuration

This directory contains the theme definitions for the ASSIGNA application.

## Files

- **themes.js** - Main theme definitions file with all color themes
- **themes.test.js** - Unit tests for theme definitions
- **validate-themes.js** - Validation script to verify theme structure

## Theme Structure

Each theme must include:

```javascript
{
  id: string,           // Unique identifier
  name: string,         // Display name
  colors: {
    background: string,    // Page background
    surface: string,       // Card/panel background
    textPrimary: string,   // Primary text
    textSecondary: string, // Secondary text
    primary: string,       // Primary brand color
    secondary: string,     // Secondary brand color
    border: string,        // Border color
    hover: string,         // Hover state background
    accent: string,        // Accent/highlight color
  }
}
```

## Available Themes

1. **Default Light** - Purple/lavender theme matching current ASSIGNA design
2. **Dark** - High contrast dark theme
3. **Blue** - Professional blue theme
4. **Green** - Nature-inspired green theme

## Adding New Themes

To add a new theme:

1. Define a theme object following the structure above
2. Add it to the `themes` array in `themes.js`
3. Run validation: `node src/config/validate-themes.js`
4. Run tests: `npm test`

## Validation

Run the validation script to verify theme definitions:

```bash
node src/config/validate-themes.js
```

This checks:
- All required themes are present
- Theme structure is valid
- All color properties are defined
- Theme IDs are unique
- Default theme has correct colors

## Testing

Run unit tests:

```bash
npm test
```

Tests verify:
- Theme structure validation
- Helper function behavior
- Edge cases and error handling
