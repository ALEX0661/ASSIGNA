/**
 * Unit tests for theme definitions
 * 
 * Tests verify that all themes are properly defined with required properties
 * and that validation functions work correctly.
 */

import { describe, it, expect } from 'vitest';
import {
  themes,
  DEFAULT_THEME_ID,
  getThemeById,
  isValidTheme,
  getValidThemes,
} from './themes.js';

describe('Theme Definitions', () => {
  describe('themes array', () => {
    it('should have at least 4 themes defined', () => {
      expect(themes.length).toBeGreaterThanOrEqual(4);
    });

    it('should include default, dark, blue, and green themes', () => {
      const themeIds = themes.map(theme => theme.id);
      expect(themeIds).toContain('default');
      expect(themeIds).toContain('dark');
      expect(themeIds).toContain('blue');
      expect(themeIds).toContain('green');
    });

    it('should have unique theme IDs', () => {
      const themeIds = themes.map(theme => theme.id);
      const uniqueIds = new Set(themeIds);
      expect(uniqueIds.size).toBe(themeIds.length);
    });
  });

  describe('theme structure', () => {
    it('should have all required top-level properties', () => {
      themes.forEach(theme => {
        expect(theme).toHaveProperty('id');
        expect(theme).toHaveProperty('name');
        expect(theme).toHaveProperty('colors');
      });
    });

    it('should have all required color properties', () => {
      const requiredColorProps = [
        'background',
        'surface',
        'textPrimary',
        'textSecondary',
        'primary',
        'secondary',
        'border',
        'hover',
        'accent',
      ];

      themes.forEach(theme => {
        requiredColorProps.forEach(prop => {
          expect(theme.colors).toHaveProperty(prop);
          expect(typeof theme.colors[prop]).toBe('string');
          expect(theme.colors[prop].length).toBeGreaterThan(0);
        });
      });
    });

    it('should have non-empty id and name strings', () => {
      themes.forEach(theme => {
        expect(typeof theme.id).toBe('string');
        expect(theme.id.length).toBeGreaterThan(0);
        expect(typeof theme.name).toBe('string');
        expect(theme.name.length).toBeGreaterThan(0);
      });
    });
  });

  describe('default theme', () => {
    it('should have purple/lavender colors', () => {
      const defaultTheme = getThemeById('default');
      expect(defaultTheme).toBeDefined();
      expect(defaultTheme.colors.primary).toBe('#7C6FCD');
      expect(defaultTheme.colors.background).toBe('#F0EEF9');
    });

    it('should be the first theme in the array', () => {
      expect(themes[0].id).toBe('default');
    });
  });

  describe('DEFAULT_THEME_ID constant', () => {
    it('should be "default"', () => {
      expect(DEFAULT_THEME_ID).toBe('default');
    });

    it('should correspond to an existing theme', () => {
      const theme = getThemeById(DEFAULT_THEME_ID);
      expect(theme).toBeDefined();
    });
  });

  describe('getThemeById function', () => {
    it('should return the correct theme for valid IDs', () => {
      const defaultTheme = getThemeById('default');
      expect(defaultTheme).toBeDefined();
      expect(defaultTheme.id).toBe('default');

      const darkTheme = getThemeById('dark');
      expect(darkTheme).toBeDefined();
      expect(darkTheme.id).toBe('dark');
    });

    it('should return undefined for invalid IDs', () => {
      const theme = getThemeById('nonexistent');
      expect(theme).toBeUndefined();
    });

    it('should return undefined for empty string', () => {
      const theme = getThemeById('');
      expect(theme).toBeUndefined();
    });
  });

  describe('isValidTheme function', () => {
    it('should return true for all defined themes', () => {
      themes.forEach(theme => {
        expect(isValidTheme(theme)).toBe(true);
      });
    });

    it('should return false for theme missing id', () => {
      const invalidTheme = {
        name: 'Test',
        colors: {
          background: '#fff',
          surface: '#fff',
          textPrimary: '#000',
          textSecondary: '#666',
          primary: '#00f',
          secondary: '#0ff',
          border: '#ccc',
          hover: '#eee',
          accent: '#ddd',
        },
      };
      expect(isValidTheme(invalidTheme)).toBe(false);
    });

    it('should return false for theme missing name', () => {
      const invalidTheme = {
        id: 'test',
        colors: {
          background: '#fff',
          surface: '#fff',
          textPrimary: '#000',
          textSecondary: '#666',
          primary: '#00f',
          secondary: '#0ff',
          border: '#ccc',
          hover: '#eee',
          accent: '#ddd',
        },
      };
      expect(isValidTheme(invalidTheme)).toBe(false);
    });

    it('should return false for theme missing colors object', () => {
      const invalidTheme = {
        id: 'test',
        name: 'Test',
      };
      expect(isValidTheme(invalidTheme)).toBe(false);
    });

    it('should return false for theme missing color properties', () => {
      const invalidTheme = {
        id: 'test',
        name: 'Test',
        colors: {
          background: '#fff',
          surface: '#fff',
          // Missing other required properties
        },
      };
      expect(isValidTheme(invalidTheme)).toBe(false);
    });

    it('should return false for null or undefined', () => {
      expect(isValidTheme(null)).toBe(false);
      expect(isValidTheme(undefined)).toBe(false);
    });

    it('should return false for non-object values', () => {
      expect(isValidTheme('string')).toBe(false);
      expect(isValidTheme(123)).toBe(false);
      expect(isValidTheme(true)).toBe(false);
    });
  });

  describe('getValidThemes function', () => {
    it('should return all themes when all are valid', () => {
      const validThemes = getValidThemes();
      expect(validThemes.length).toBe(themes.length);
    });

    it('should return only valid themes', () => {
      const validThemes = getValidThemes();
      validThemes.forEach(theme => {
        expect(isValidTheme(theme)).toBe(true);
      });
    });
  });

  describe('color format', () => {
    it('should use hex color format for all colors', () => {
      const hexColorRegex = /^#[0-9A-Fa-f]{6}$/;
      
      themes.forEach(theme => {
        Object.values(theme.colors).forEach(color => {
          expect(color).toMatch(hexColorRegex);
        });
      });
    });
  });

  describe('theme names', () => {
    it('should have descriptive names', () => {
      const defaultTheme = getThemeById('default');
      expect(defaultTheme.name).toBe('Default Light');

      const darkTheme = getThemeById('dark');
      expect(darkTheme.name).toBe('Dark');

      const blueTheme = getThemeById('blue');
      expect(blueTheme.name).toBe('Blue');

      const greenTheme = getThemeById('green');
      expect(greenTheme.name).toBe('Green');
    });
  });
});
