# Accessibility Utility Functions

This module provides utility functions for color contrast validation and adjustment according to WCAG 2.1 Level AA standards.

## Functions

### `hexToRgb(hex)`
Converts a hex color string to RGB values.

**Parameters:**
- `hex` (string): Hex color string (e.g., "#FF5733" or "FF5733")

**Returns:**
- `[number, number, number]`: Array of RGB values [r, g, b] where each value is 0-255

**Example:**
```javascript
hexToRgb("#FF5733") // returns [255, 87, 51]
```

### `getRelativeLuminance(hexColor)`
Calculates the relative luminance of a color according to WCAG formula.

**Parameters:**
- `hexColor` (string): Hex color string

**Returns:**
- `number`: Relative luminance value between 0 and 1

**Example:**
```javascript
getRelativeLuminance("#FFFFFF") // returns 1 (white)
getRelativeLuminance("#000000") // returns 0 (black)
```

### `getContrastRatio(color1, color2)`
Calculates the contrast ratio between two colors according to WCAG formula.

**Parameters:**
- `color1` (string): First hex color string
- `color2` (string): Second hex color string

**Returns:**
- `number`: Contrast ratio between 1 and 21

**Example:**
```javascript
getContrastRatio("#FFFFFF", "#000000") // returns 21 (maximum contrast)
```

### `rgbToHex(r, g, b)`
Converts RGB values to hex color string.

**Parameters:**
- `r` (number): Red value (0-255)
- `g` (number): Green value (0-255)
- `b` (number): Blue value (0-255)

**Returns:**
- `string`: Hex color string with # prefix

**Example:**
```javascript
rgbToHex(255, 87, 51) // returns "#FF5733"
```

### `adjustLightness(hexColor, percent)`
Adjusts the lightness of a color by a percentage.

**Parameters:**
- `hexColor` (string): Hex color string
- `percent` (number): Percentage to adjust (-100 to 100, negative darkens, positive lightens)

**Returns:**
- `string`: Adjusted hex color string

**Example:**
```javascript
adjustLightness("#FF5733", 20)  // returns lighter version
adjustLightness("#FF5733", -20) // returns darker version
```

### `adjustForContrast(textColor, bgColor, targetRatio, maxIterations)`
Automatically adjusts a text color to meet WCAG contrast requirements against a background.

**Parameters:**
- `textColor` (string): Hex color string for text
- `bgColor` (string): Hex color string for background
- `targetRatio` (number, optional): Target contrast ratio (default: 4.5 for normal text)
- `maxIterations` (number, optional): Maximum adjustment iterations (default: 50)

**Returns:**
- `string`: Adjusted text color that meets the target contrast ratio

**Example:**
```javascript
adjustForContrast("#888888", "#FFFFFF", 4.5) // returns darker gray that meets 4.5:1 ratio
```

### `validateContrast(textColor, bgColor, isLargeText)`
Validates if a color combination meets WCAG contrast requirements.

**Parameters:**
- `textColor` (string): Hex color string for text
- `bgColor` (string): Hex color string for background
- `isLargeText` (boolean, optional): Whether the text is large (18px+ or 14px+ bold)

**Returns:**
- `Object`: Validation result with `passes`, `ratio`, and `required` properties

**Example:**
```javascript
validateContrast("#000000", "#FFFFFF", false) 
// returns { passes: true, ratio: 21, required: 4.5 }
```

## WCAG 2.1 Level AA Requirements

- **Normal text** (< 18px): Minimum contrast ratio of **4.5:1**
- **Large text** (≥ 18px or ≥ 14px bold): Minimum contrast ratio of **3:1**
- **Interactive elements**: Minimum contrast ratio of **4.5:1** in all states
- **Focus indicators**: Minimum contrast ratio of **3:1**

## Testing

All functions have been tested with comprehensive unit tests covering:
- Basic functionality
- Edge cases (pure white, pure black, boundary values)
- Error handling (invalid inputs)
- WCAG compliance
- Round-trip conversions
- Contrast symmetry

Run tests with:
```bash
npm test
```

Or run manual tests with:
```bash
node src/utils/test-accessibility-manual.js
```

## Implementation Details

The functions implement the WCAG 2.1 relative luminance and contrast ratio formulas:

**Relative Luminance:**
```
L = 0.2126 * R + 0.7152 * G + 0.0722 * B
```

Where R, G, B are the linearized RGB values:
```
if (val <= 0.03928) {
  val = val / 12.92
} else {
  val = ((val + 0.055) / 1.055) ^ 2.4
}
```

**Contrast Ratio:**
```
(L1 + 0.05) / (L2 + 0.05)
```

Where L1 is the lighter color and L2 is the darker color.

## Usage in Theme System

These utilities are used by the theme system to:
1. Validate that all theme colors meet WCAG contrast requirements
2. Automatically adjust colors that fail contrast checks
3. Ensure accessibility compliance across all themes
4. Provide runtime contrast validation for dynamic color changes

## References

- [WCAG 2.1 Contrast (Minimum)](https://www.w3.org/WAI/WCAG21/Understanding/contrast-minimum.html)
- [WCAG 2.1 Relative Luminance](https://www.w3.org/WAI/GL/wiki/Relative_luminance)
- [WebAIM Contrast Checker](https://webaim.org/resources/contrastchecker/)
