/**
 * Manual test runner for accessibility utility functions
 * Run with: node src/utils/test-accessibility-manual.js
 */

import {
  hexToRgb,
  getRelativeLuminance,
  getContrastRatio,
  rgbToHex,
  adjustLightness,
  adjustForContrast,
  validateContrast
} from './accessibility.js';

let passedTests = 0;
let failedTests = 0;

function assert(condition, message) {
  if (condition) {
    passedTests++;
    console.log(`✓ ${message}`);
  } else {
    failedTests++;
    console.log(`✗ ${message}`);
  }
}

function assertArrayEquals(arr1, arr2, message) {
  const equal = JSON.stringify(arr1) === JSON.stringify(arr2);
  assert(equal, message + ` (expected ${JSON.stringify(arr2)}, got ${JSON.stringify(arr1)})`);
}

function assertClose(val1, val2, tolerance, message) {
  const close = Math.abs(val1 - val2) < tolerance;
  assert(close, message + ` (expected ~${val2}, got ${val1})`);
}

console.log('\n=== Testing hexToRgb ===\n');
assertArrayEquals(hexToRgb('#FF5733'), [255, 87, 51], 'Convert hex with # to RGB');
assertArrayEquals(hexToRgb('FF5733'), [255, 87, 51], 'Convert hex without # to RGB');
assertArrayEquals(hexToRgb('#FFFFFF'), [255, 255, 255], 'Convert white to RGB');
assertArrayEquals(hexToRgb('#000000'), [0, 0, 0], 'Convert black to RGB');

try {
  hexToRgb('#GGG');
  assert(false, 'Should throw error for invalid hex');
} catch (e) {
  assert(true, 'Throws error for invalid hex format');
}

console.log('\n=== Testing getRelativeLuminance ===\n');
assert(getRelativeLuminance('#FFFFFF') === 1, 'White has luminance of 1');
assert(getRelativeLuminance('#000000') === 0, 'Black has luminance of 0');
assertClose(getRelativeLuminance('#FF0000'), 0.2126, 0.0001, 'Red luminance');
assertClose(getRelativeLuminance('#00FF00'), 0.7152, 0.0001, 'Green luminance');
assertClose(getRelativeLuminance('#0000FF'), 0.0722, 0.0001, 'Blue luminance');

console.log('\n=== Testing getContrastRatio ===\n');
assert(getContrastRatio('#FFFFFF', '#000000') === 21, 'Black/white has 21:1 contrast');
assert(getContrastRatio('#000000', '#FFFFFF') === 21, 'Contrast is symmetric');
assert(getContrastRatio('#FFFFFF', '#FFFFFF') === 1, 'Same colors have 1:1 contrast');
assert(getContrastRatio('#333333', '#FFFFFF') > 4.5, 'Dark gray on white meets WCAG AA');

console.log('\n=== Testing rgbToHex ===\n');
assert(rgbToHex(255, 87, 51) === '#FF5733', 'Convert RGB to hex');
assert(rgbToHex(255, 255, 255) === '#FFFFFF', 'Convert white to hex');
assert(rgbToHex(0, 0, 0) === '#000000', 'Convert black to hex');
assert(rgbToHex(0, 0, 1) === '#000001', 'Pad single digit hex values');
assert(rgbToHex(300, 87, 51) === '#FF5733', 'Clamp values above 255');
assert(rgbToHex(-10, 87, 51) === '#005733', 'Clamp values below 0');

console.log('\n=== Testing adjustLightness ===\n');
const gray = '#808080';
const lightened = adjustLightness(gray, 20);
const darkened = adjustLightness(gray, -20);
assert(getRelativeLuminance(lightened) > getRelativeLuminance(gray), 'Positive % lightens color');
assert(getRelativeLuminance(darkened) < getRelativeLuminance(gray), 'Negative % darkens color');
assert(adjustLightness(gray, 0) === gray, 'Zero % does not change color');
assert(adjustLightness('#808080', 100) === '#FFFFFF', 'Lighten 100% approaches white');
assert(adjustLightness('#808080', -100) === '#000000', 'Darken 100% approaches black');

console.log('\n=== Testing adjustForContrast ===\n');
assert(adjustForContrast('#000000', '#FFFFFF', 4.5) === '#000000', 'Returns original if already meets target');

const adjusted1 = adjustForContrast('#CCCCCC', '#FFFFFF', 4.5);
const ratio1 = getContrastRatio(adjusted1, '#FFFFFF');
assert(ratio1 >= 4.5, `Adjusts light text on light bg to meet 4.5:1 (got ${ratio1.toFixed(2)}:1)`);

const adjusted2 = adjustForContrast('#333333', '#000000', 4.5);
const ratio2 = getContrastRatio(adjusted2, '#000000');
assert(ratio2 >= 4.5, `Adjusts dark text on dark bg to meet 4.5:1 (got ${ratio2.toFixed(2)}:1)`);

const adjusted3 = adjustForContrast('#888888', '#FFFFFF', 4.5);
const ratio3 = getContrastRatio(adjusted3, '#FFFFFF');
assert(ratio3 >= 4.5, `Meets WCAG AA normal text requirement (got ${ratio3.toFixed(2)}:1)`);

const adjusted4 = adjustForContrast('#AAAAAA', '#FFFFFF', 3.0);
const ratio4 = getContrastRatio(adjusted4, '#FFFFFF');
assert(ratio4 >= 3.0, `Meets WCAG AA large text requirement (got ${ratio4.toFixed(2)}:1)`);

console.log('\n=== Testing validateContrast ===\n');
const result1 = validateContrast('#000000', '#FFFFFF', false);
assert(result1.passes === true && result1.ratio === 21 && result1.required === 4.5, 'Black on white passes for normal text');

const result2 = validateContrast('#000000', '#FFFFFF', true);
assert(result2.passes === true && result2.required === 3.0, 'Black on white passes for large text');

const result3 = validateContrast('#CCCCCC', '#FFFFFF', false);
assert(result3.passes === false && result3.required === 4.5, 'Low contrast fails for normal text');

const result4 = validateContrast('#FFFFFF', '#FFFFFF', false);
assert(result4.passes === false && result4.ratio === 1, 'Same colors fail validation');

console.log('\n=== Testing Edge Cases ===\n');
// Round-trip conversion
const original = '#FF5733';
const [r, g, b] = hexToRgb(original);
const converted = rgbToHex(r, g, b);
assert(converted === original, 'Round-trip hex -> RGB -> hex preserves value');

// Contrast symmetry
const colors = ['#FFFFFF', '#000000', '#FF5733', '#808080'];
let symmetryPassed = true;
colors.forEach(color1 => {
  colors.forEach(color2 => {
    const ratio1 = getContrastRatio(color1, color2);
    const ratio2 = getContrastRatio(color2, color1);
    if (Math.abs(ratio1 - ratio2) > 0.0001) {
      symmetryPassed = false;
    }
  });
});
assert(symmetryPassed, 'Contrast ratio is symmetric for all color pairs');

// Adjusted colors meet target
const testCases = [
  { text: '#888888', bg: '#FFFFFF', target: 4.5 },
  { text: '#AAAAAA', bg: '#000000', target: 4.5 },
  { text: '#CCCCCC', bg: '#FFFFFF', target: 3.0 },
  { text: '#666666', bg: '#F0F0F0', target: 4.5 },
];

let allMeetTarget = true;
testCases.forEach(({ text, bg, target }) => {
  const adjusted = adjustForContrast(text, bg, target);
  const ratio = getContrastRatio(adjusted, bg);
  if (ratio < target - 0.1) {
    allMeetTarget = false;
    console.log(`  Failed: ${text} on ${bg} target ${target} got ${ratio.toFixed(2)}`);
  }
});
assert(allMeetTarget, 'All adjusted colors meet or exceed target ratio');

console.log('\n=== Test Summary ===\n');
console.log(`Passed: ${passedTests}`);
console.log(`Failed: ${failedTests}`);
console.log(`Total: ${passedTests + failedTests}`);

if (failedTests === 0) {
  console.log('\n✅ All tests passed!\n');
  process.exit(0);
} else {
  console.log(`\n❌ ${failedTests} test(s) failed\n`);
  process.exit(1);
}
