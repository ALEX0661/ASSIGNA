import { describe, it, expect } from 'vitest';
import {
  hexToRgb,
  getRelativeLuminance,
  getContrastRatio,
  rgbToHex,
  adjustLightness,
  adjustForContrast,
  validateContrast
} from './accessibility';

describe('hexToRgb', () => {
  it('should convert hex color with # prefix to RGB', () => {
    expect(hexToRgb('#FF5733')).toEqual([255, 87, 51]);
  });

  it('should convert hex color without # prefix to RGB', () => {
    expect(hexToRgb('FF5733')).toEqual([255, 87, 51]);
  });

  it('should handle lowercase hex colors', () => {
    expect(hexToRgb('#ff5733')).toEqual([255, 87, 51]);
  });

  it('should handle pure white', () => {
    expect(hexToRgb('#FFFFFF')).toEqual([255, 255, 255]);
  });

  it('should handle pure black', () => {
    expect(hexToRgb('#000000')).toEqual([0, 0, 0]);
  });

  it('should throw error for invalid hex format', () => {
    expect(() => hexToRgb('#GGG')).toThrow('Invalid hex color');
    expect(() => hexToRgb('12345')).toThrow('Invalid hex color');
    expect(() => hexToRgb('#12345G')).toThrow('Invalid hex color');
  });

  it('should handle edge case colors', () => {
    expect(hexToRgb('#000001')).toEqual([0, 0, 1]);
    expect(hexToRgb('#FFFFFE')).toEqual([255, 255, 254]);
  });
});

describe('getRelativeLuminance', () => {
  it('should return 1 for pure white', () => {
    expect(getRelativeLuminance('#FFFFFF')).toBe(1);
  });

  it('should return 0 for pure black', () => {
    expect(getRelativeLuminance('#000000')).toBe(0);
  });

  it('should calculate luminance for gray colors', () => {
    const luminance = getRelativeLuminance('#808080');
    expect(luminance).toBeGreaterThan(0);
    expect(luminance).toBeLessThan(1);
  });

  it('should calculate luminance for red', () => {
    const luminance = getRelativeLuminance('#FF0000');
    expect(luminance).toBeCloseTo(0.2126, 4);
  });

  it('should calculate luminance for green', () => {
    const luminance = getRelativeLuminance('#00FF00');
    expect(luminance).toBeCloseTo(0.7152, 4);
  });

  it('should calculate luminance for blue', () => {
    const luminance = getRelativeLuminance('#0000FF');
    expect(luminance).toBeCloseTo(0.0722, 4);
  });

  it('should handle colors with low RGB values', () => {
    const luminance = getRelativeLuminance('#010101');
    expect(luminance).toBeGreaterThan(0);
    expect(luminance).toBeLessThan(0.01);
  });
});

describe('getContrastRatio', () => {
  it('should return 21 for black on white (maximum contrast)', () => {
    expect(getContrastRatio('#FFFFFF', '#000000')).toBe(21);
    expect(getContrastRatio('#000000', '#FFFFFF')).toBe(21);
  });

  it('should return 1 for same colors (no contrast)', () => {
    expect(getContrastRatio('#FFFFFF', '#FFFFFF')).toBe(1);
    expect(getContrastRatio('#000000', '#000000')).toBe(1);
    expect(getContrastRatio('#FF5733', '#FF5733')).toBe(1);
  });

  it('should be symmetric (order should not matter)', () => {
    const ratio1 = getContrastRatio('#FF5733', '#FFFFFF');
    const ratio2 = getContrastRatio('#FFFFFF', '#FF5733');
    expect(ratio1).toBe(ratio2);
  });

  it('should calculate contrast for typical text/background combinations', () => {
    // Dark text on light background
    const ratio1 = getContrastRatio('#333333', '#FFFFFF');
    expect(ratio1).toBeGreaterThan(4.5); // Should meet WCAG AA

    // Light text on dark background
    const ratio2 = getContrastRatio('#FFFFFF', '#333333');
    expect(ratio2).toBeGreaterThan(4.5);
  });

  it('should handle edge case: very similar colors', () => {
    const ratio = getContrastRatio('#FFFFFF', '#FFFFFE');
    expect(ratio).toBeCloseTo(1, 1);
  });

  it('should calculate contrast for gray scale', () => {
    const ratio = getContrastRatio('#808080', '#FFFFFF');
    expect(ratio).toBeGreaterThan(1);
    expect(ratio).toBeLessThan(21);
  });
});

describe('rgbToHex', () => {
  it('should convert RGB to hex with # prefix', () => {
    expect(rgbToHex(255, 87, 51)).toBe('#FF5733');
  });

  it('should handle pure white', () => {
    expect(rgbToHex(255, 255, 255)).toBe('#FFFFFF');
  });

  it('should handle pure black', () => {
    expect(rgbToHex(0, 0, 0)).toBe('#000000');
  });

  it('should pad single digit hex values with zero', () => {
    expect(rgbToHex(0, 0, 1)).toBe('#000001');
    expect(rgbToHex(15, 15, 15)).toBe('#0F0F0F');
  });

  it('should clamp values above 255', () => {
    expect(rgbToHex(300, 87, 51)).toBe('#FF5733');
  });

  it('should clamp values below 0', () => {
    expect(rgbToHex(-10, 87, 51)).toBe('#005733');
  });

  it('should round decimal values', () => {
    expect(rgbToHex(255.7, 87.3, 51.5)).toBe('#FF5734');
  });
});

describe('adjustLightness', () => {
  it('should lighten a color with positive percentage', () => {
    const original = '#808080';
    const lightened = adjustLightness(original, 20);
    const originalLum = getRelativeLuminance(original);
    const lightenedLum = getRelativeLuminance(lightened);
    expect(lightenedLum).toBeGreaterThan(originalLum);
  });

  it('should darken a color with negative percentage', () => {
    const original = '#808080';
    const darkened = adjustLightness(original, -20);
    const originalLum = getRelativeLuminance(original);
    const darkenedLum = getRelativeLuminance(darkened);
    expect(darkenedLum).toBeLessThan(originalLum);
  });

  it('should not change color with 0 percentage', () => {
    const original = '#808080';
    const unchanged = adjustLightness(original, 0);
    expect(unchanged).toBe(original);
  });

  it('should approach white when lightening by 100%', () => {
    const lightened = adjustLightness('#808080', 100);
    expect(lightened).toBe('#FFFFFF');
  });

  it('should approach black when darkening by -100%', () => {
    const darkened = adjustLightness('#808080', -100);
    expect(darkened).toBe('#000000');
  });

  it('should handle already white color', () => {
    const result = adjustLightness('#FFFFFF', 20);
    expect(result).toBe('#FFFFFF');
  });

  it('should handle already black color', () => {
    const result = adjustLightness('#000000', -20);
    expect(result).toBe('#000000');
  });
});

describe('adjustForContrast', () => {
  it('should return original color if it already meets target ratio', () => {
    const textColor = '#000000';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    expect(adjusted).toBe(textColor);
  });

  it('should adjust light text on light background to be darker', () => {
    const textColor = '#CCCCCC';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    const ratio = getContrastRatio(adjusted, bgColor);
    expect(ratio).toBeGreaterThanOrEqual(4.5);
    expect(getRelativeLuminance(adjusted)).toBeLessThan(getRelativeLuminance(textColor));
  });

  it('should adjust dark text on dark background to be lighter', () => {
    const textColor = '#333333';
    const bgColor = '#000000';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    const ratio = getContrastRatio(adjusted, bgColor);
    expect(ratio).toBeGreaterThanOrEqual(4.5);
    expect(getRelativeLuminance(adjusted)).toBeGreaterThan(getRelativeLuminance(textColor));
  });

  it('should meet WCAG AA normal text requirement (4.5:1)', () => {
    const textColor = '#888888';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    const ratio = getContrastRatio(adjusted, bgColor);
    expect(ratio).toBeGreaterThanOrEqual(4.5);
  });

  it('should meet WCAG AA large text requirement (3:1)', () => {
    const textColor = '#AAAAAA';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 3.0);
    const ratio = getContrastRatio(adjusted, bgColor);
    expect(ratio).toBeGreaterThanOrEqual(3.0);
  });

  it('should handle edge case: impossible contrast on mid-gray background', () => {
    const textColor = '#808080';
    const bgColor = '#808080';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    // Should adjust as much as possible
    expect(adjusted).not.toBe(textColor);
  });

  it('should respect maxIterations parameter', () => {
    const textColor = '#FEFEFE';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5, 5);
    // With only 5 iterations, it might not reach the target
    expect(adjusted).toBeDefined();
  });

  it('should stop at pure white when lightening', () => {
    const textColor = '#333333';
    const bgColor = '#000000';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    const [r, g, b] = hexToRgb(adjusted);
    // Should not exceed 255
    expect(r).toBeLessThanOrEqual(255);
    expect(g).toBeLessThanOrEqual(255);
    expect(b).toBeLessThanOrEqual(255);
  });

  it('should stop at pure black when darkening', () => {
    const textColor = '#CCCCCC';
    const bgColor = '#FFFFFF';
    const adjusted = adjustForContrast(textColor, bgColor, 4.5);
    const [r, g, b] = hexToRgb(adjusted);
    // Should not go below 0
    expect(r).toBeGreaterThanOrEqual(0);
    expect(g).toBeGreaterThanOrEqual(0);
    expect(b).toBeGreaterThanOrEqual(0);
  });
});

describe('validateContrast', () => {
  it('should pass for black on white (normal text)', () => {
    const result = validateContrast('#000000', '#FFFFFF', false);
    expect(result.passes).toBe(true);
    expect(result.ratio).toBe(21);
    expect(result.required).toBe(4.5);
  });

  it('should pass for black on white (large text)', () => {
    const result = validateContrast('#000000', '#FFFFFF', true);
    expect(result.passes).toBe(true);
    expect(result.ratio).toBe(21);
    expect(result.required).toBe(3.0);
  });

  it('should fail for low contrast normal text', () => {
    const result = validateContrast('#CCCCCC', '#FFFFFF', false);
    expect(result.passes).toBe(false);
    expect(result.ratio).toBeLessThan(4.5);
    expect(result.required).toBe(4.5);
  });

  it('should pass for low contrast large text', () => {
    const result = validateContrast('#999999', '#FFFFFF', true);
    const passes = result.ratio >= 3.0;
    expect(result.passes).toBe(passes);
    expect(result.required).toBe(3.0);
  });

  it('should fail for same colors', () => {
    const result = validateContrast('#FFFFFF', '#FFFFFF', false);
    expect(result.passes).toBe(false);
    expect(result.ratio).toBe(1);
  });

  it('should round ratio to 2 decimal places', () => {
    const result = validateContrast('#808080', '#FFFFFF');
    expect(result.ratio).toBe(Math.round(result.ratio * 100) / 100);
  });

  it('should use 4.5:1 as default for normal text', () => {
    const result = validateContrast('#000000', '#FFFFFF');
    expect(result.required).toBe(4.5);
  });

  it('should use 3:1 for large text', () => {
    const result = validateContrast('#000000', '#FFFFFF', true);
    expect(result.required).toBe(3.0);
  });
});

describe('Edge cases and integration', () => {
  it('should handle round-trip conversion hex -> rgb -> hex', () => {
    const original = '#FF5733';
    const [r, g, b] = hexToRgb(original);
    const converted = rgbToHex(r, g, b);
    expect(converted).toBe(original);
  });

  it('should maintain contrast ratio symmetry', () => {
    const colors = ['#FFFFFF', '#000000', '#FF5733', '#808080'];
    colors.forEach(color1 => {
      colors.forEach(color2 => {
        const ratio1 = getContrastRatio(color1, color2);
        const ratio2 = getContrastRatio(color2, color1);
        expect(ratio1).toBeCloseTo(ratio2, 10);
      });
    });
  });

  it('should ensure adjusted colors always meet or exceed target ratio', () => {
    const testCases = [
      { text: '#888888', bg: '#FFFFFF', target: 4.5 },
      { text: '#AAAAAA', bg: '#000000', target: 4.5 },
      { text: '#CCCCCC', bg: '#FFFFFF', target: 3.0 },
      { text: '#666666', bg: '#F0F0F0', target: 4.5 },
    ];

    testCases.forEach(({ text, bg, target }) => {
      const adjusted = adjustForContrast(text, bg, target);
      const ratio = getContrastRatio(adjusted, bg);
      // Allow small tolerance for edge cases where perfect ratio is impossible
      expect(ratio).toBeGreaterThanOrEqual(target - 0.1);
    });
  });

  it('should handle all valid hex color formats', () => {
    const formats = ['#FF5733', 'FF5733', '#ff5733', 'ff5733'];
    formats.forEach(format => {
      expect(() => hexToRgb(format)).not.toThrow();
      const [r, g, b] = hexToRgb(format);
      expect(r).toBe(255);
      expect(g).toBe(87);
      expect(b).toBe(51);
    });
  });
});
