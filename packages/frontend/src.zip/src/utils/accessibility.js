/**
 * Accessibility utility functions for color contrast validation and adjustment.
 * Implements WCAG 2.1 Level AA contrast requirements.
 */

/**
 * Converts a hex color string to RGB values.
 * @param {string} hex - Hex color string (e.g., "#FF5733" or "FF5733")
 * @returns {[number, number, number]} Array of RGB values [r, g, b] where each value is 0-255
 * @throws {Error} If hex string is invalid
 * 
 * @example
 * hexToRgb("#FF5733") // returns [255, 87, 51]
 * hexToRgb("FF5733")  // returns [255, 87, 51]
 */
export function hexToRgb(hex) {
  // Remove # if present
  const cleanHex = hex.replace(/^#/, '');
  
  // Validate hex format
  if (!/^[0-9A-Fa-f]{6}$/.test(cleanHex)) {
    throw new Error(`Invalid hex color: ${hex}`);
  }
  
  // Parse hex to RGB
  const r = parseInt(cleanHex.substring(0, 2), 16);
  const g = parseInt(cleanHex.substring(2, 4), 16);
  const b = parseInt(cleanHex.substring(4, 6), 16);
  
  return [r, g, b];
}

/**
 * Calculates the relative luminance of a color according to WCAG formula.
 * @param {string} hexColor - Hex color string (e.g., "#FF5733")
 * @returns {number} Relative luminance value between 0 and 1
 * 
 * @example
 * getRelativeLuminance("#FFFFFF") // returns 1 (white)
 * getRelativeLuminance("#000000") // returns 0 (black)
 */
export function getRelativeLuminance(hexColor) {
  const rgb = hexToRgb(hexColor);
  
  // Convert RGB values to sRGB
  const [r, g, b] = rgb.map(val => {
    val = val / 255;
    return val <= 0.03928 
      ? val / 12.92 
      : Math.pow((val + 0.055) / 1.055, 2.4);
  });
  
  // Calculate relative luminance using WCAG formula
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/**
 * Calculates the contrast ratio between two colors according to WCAG formula.
 * @param {string} color1 - First hex color string
 * @param {string} color2 - Second hex color string
 * @returns {number} Contrast ratio between 1 and 21
 * 
 * @example
 * getContrastRatio("#FFFFFF", "#000000") // returns 21 (maximum contrast)
 * getContrastRatio("#FFFFFF", "#FFFFFF") // returns 1 (no contrast)
 */
export function getContrastRatio(color1, color2) {
  const l1 = getRelativeLuminance(color1);
  const l2 = getRelativeLuminance(color2);
  
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  
  return (lighter + 0.05) / (darker + 0.05);
}

/**
 * Converts RGB values to hex color string.
 * @param {number} r - Red value (0-255)
 * @param {number} g - Green value (0-255)
 * @param {number} b - Blue value (0-255)
 * @returns {string} Hex color string with # prefix
 * 
 * @example
 * rgbToHex(255, 87, 51) // returns "#FF5733"
 */
export function rgbToHex(r, g, b) {
  const toHex = (val) => {
    const clamped = Math.max(0, Math.min(255, Math.round(val)));
    return clamped.toString(16).padStart(2, '0').toUpperCase();
  };
  
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

/**
 * Adjusts the lightness of a color by a percentage.
 * @param {string} hexColor - Hex color string
 * @param {number} percent - Percentage to adjust (-100 to 100, negative darkens, positive lightens)
 * @returns {string} Adjusted hex color string
 * 
 * @example
 * adjustLightness("#FF5733", 20)  // returns lighter version
 * adjustLightness("#FF5733", -20) // returns darker version
 */
export function adjustLightness(hexColor, percent) {
  const [r, g, b] = hexToRgb(hexColor);
  
  // Adjust each channel
  const adjust = (val) => {
    if (percent > 0) {
      // Lighten: move towards 255
      return val + (255 - val) * (percent / 100);
    } else {
      // Darken: move towards 0
      return val * (1 + percent / 100);
    }
  };
  
  return rgbToHex(adjust(r), adjust(g), adjust(b));
}

/**
 * Automatically adjusts a text color to meet WCAG contrast requirements against a background.
 * @param {string} textColor - Hex color string for text
 * @param {string} bgColor - Hex color string for background
 * @param {number} targetRatio - Target contrast ratio (default: 4.5 for normal text)
 * @param {number} maxIterations - Maximum adjustment iterations (default: 50)
 * @returns {string} Adjusted text color that meets the target contrast ratio
 * 
 * @example
 * adjustForContrast("#888888", "#FFFFFF", 4.5) // returns darker gray that meets 4.5:1 ratio
 * adjustForContrast("#CCCCCC", "#000000", 3.0) // returns lighter gray that meets 3:1 ratio
 */
export function adjustForContrast(textColor, bgColor, targetRatio = 4.5, maxIterations = 50) {
  let adjusted = textColor;
  let ratio = getContrastRatio(adjusted, bgColor);
  
  // If already meets target, return as-is
  if (ratio >= targetRatio) {
    return adjusted;
  }
  
  // Determine if we need to lighten or darken
  const bgLuminance = getRelativeLuminance(bgColor);
  const shouldLighten = bgLuminance < 0.5;
  
  let iteration = 0;
  const step = shouldLighten ? 5 : -5;
  
  while (ratio < targetRatio && iteration < maxIterations) {
    adjusted = adjustLightness(adjusted, step);
    ratio = getContrastRatio(adjusted, bgColor);
    iteration++;
    
    // If we've gone too far (reached pure white or black), stop
    const [r, g, b] = hexToRgb(adjusted);
    if (shouldLighten && r >= 255 && g >= 255 && b >= 255) {
      break;
    }
    if (!shouldLighten && r <= 0 && g <= 0 && b <= 0) {
      break;
    }
  }
  
  return adjusted;
}

/**
 * Validates if a color combination meets WCAG contrast requirements.
 * @param {string} textColor - Hex color string for text
 * @param {string} bgColor - Hex color string for background
 * @param {boolean} isLargeText - Whether the text is large (18px+ or 14px+ bold)
 * @returns {Object} Validation result with passes, ratio, and required properties
 * 
 * @example
 * validateContrast("#000000", "#FFFFFF", false) 
 * // returns { passes: true, ratio: 21, required: 4.5 }
 */
export function validateContrast(textColor, bgColor, isLargeText = false) {
  const ratio = getContrastRatio(textColor, bgColor);
  const required = isLargeText ? 3.0 : 4.5;
  
  return {
    passes: ratio >= required,
    ratio: Math.round(ratio * 100) / 100,
    required
  };
}
